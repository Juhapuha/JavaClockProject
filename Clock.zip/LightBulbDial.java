//import javax.swing.JPanel;
import java.util.Calendar;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.RenderingHints;
import java.awt.RadialGradientPaint;

public class LightBulbDial extends BasicDial {
	
	// Seuraavat kaksi kentt�� ovat hehkulamppujen "hehkuv�rin" luontia varten (RadialGradientPaint).
	private Color[] colors = { new Color( 239, 191, 75, 255 ), new Color( 255, 255, 0, 255 ), new Color( 255, 255, 0, 0 ) };
	private float[] fractions = { 0.05f, 0.27f, 0.99f };
	
	public void drawDial( Calendar time ) {
		setTime( time );
		repaint( 0 );
	}
	
	public Dimension getPreferredSize() {
		return new Dimension( 300, 320 );
	}
	
	protected void paintComponent( Graphics g ) {
		super.paintComponent( g );
		
		// Muunnetaan Graphics-objekti Graphics2D-objektiksi.
		Graphics2D g2D = (Graphics2D) g;
		
		g2D.setRenderingHint( RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON );
		
		// Piirret��n kaikki lamppujonot pystysuunnassa.
		drawBulbStack( g2D, giveAsBinary( getHours() / 10 ), 0 + 20 );
		drawBulbStack( g2D, giveAsBinary( getHours() % 10 ), 50 + 14 );
		drawBulbStack( g2D, giveAsBinary( getMinutes() / 10 ), 100 + 20 );
		drawBulbStack( g2D, giveAsBinary( getMinutes() % 10 ), 150 + 14 );
		drawBulbStack( g2D, giveAsBinary( getSeconds() / 10 ), 200 + 20 );
		drawBulbStack( g2D, giveAsBinary( getSeconds() % 10 ), 250 + 14 );
	}
	
	private void drawBulbStack( Graphics2D g, String binary, int offset ) {
		// K�yd��n l�pi lamppujonon kaikki lamput ylh��lt� alas.
		for ( int bulb = 0; bulb < 4; bulb++ ) {
			
			// Piirret��n lamppu ensin siten, ettei se ole p��ll�.
			g.setColor( Color.BLACK );
			g.drawOval( offset, getHeight() / 2 - 100 + 17 + bulb * 50, 16, 16 );
			
			// Jos lampun kuuluu olla p��ll�, piirret��n lampun p��lle hehkuvalo.
			if ( binary.charAt( bulb ) == '1' ) {
				g.setPaint( new RadialGradientPaint( (float) (offset + 8),
								(float) (getHeight() / 2 - 100 + 17 + bulb * 50 + 8),
									25f, fractions, colors ) );
				g.fillOval( offset - 17, getHeight() / 2 - 100 + 17 + bulb * 50 - 17, 50, 50 );
			}
		}
	}
	
	private String giveAsBinary( int n ) {
		return String.format( "%04d", Integer.parseInt( Integer.toBinaryString( n ) ) );
	}
}