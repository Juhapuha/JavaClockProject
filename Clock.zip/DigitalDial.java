//import javax.swing.JPanel;
import java.util.Calendar;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Polygon;
import java.awt.RenderingHints;

public class DigitalDial extends BasicDial {
	
	// N�ill� muuttujilla kontrolloidaan n�yt�n kaksoispisteiden n�kyvyytt�.
	private int half = 0;
	private boolean colons = true;
	
	// Taulukot kullekin digitaalinumerolle. Totuusarvot ilmaisevat kunkin segmentin n�kyvyyden.
	private final boolean[][] segmentArrays = { { true, true, true, false, true, true, true },		// 0
												{ false, false, true, false, false, true, false },	// 1
												{ true, false, true, true, true, false, true },		// 2
												{ true, false, true, true, false, true, true },		// 3
												{ false, true, true, true, false, true, false },	// 4
												{ true, true, false, true, false, true, true },		// 5
												{ true, true, false, true, true, true, true },		// 6
												{ true, false, true, false, false, true, false },	// 7
												{ true, true, true, true, true, true, true },		// 8
												{ true, true, true, true, false, true, true } };	// 9
	
	// Seuraavat kolme muuttujaa ovat segmenttipolygonien luontia varten.
	private final int[][] xpointsArray = {	{ 0, 8, 55, 47, 17 }, { 0, 15, 15, 8, 0 },
											{ 57, 64, 64, 56, 49, 49 }, { 9, 17, 47, 55, 47, 17 },
											{ 8, 15, 15, 0, 0 }, { 56, 64, 64, 57, 49, 49 },
											{ 0, 17, 47, 55, 8 } };
	private final int[][] ypointsArray = {	{ 7, 0, 0, 15, 15 }, { 9, 16, 47, 55, 48 },
											{ 0, 8, 48, 55, 47, 16 }, { 56, 49, 49, 56, 63, 63 },
											{ 57, 65, 96, 103, 64 }, { 57, 64, 104, 112, 96, 65 },
											{ 105, 97, 97, 112, 112 } };
	private final int[] totalPoints = { 5, 5, 6, 6, 5, 6, 5 };
	
	public void drawDial( Calendar time ) {
		setTime( time );
		half = getMilliSeconds();
		// Vaihdetaan colons-muuttuja siten, ett� kaksoispisteet vilkkuvat n�yt�ll�
		// vuorotellen puolen sekunnin v�lein.
		if ( ( half < 500 && !colons ) || ( half >= 500 && colons ) )
			colons = !colons;
		repaint( 0 );
	}
	
	public Dimension getPreferredSize() {
		return new Dimension( 588, 200 );
	}
	
	protected void paintComponent( Graphics g ) {
		super.paintComponent( g );
		
		// Muunnetaan Graphics-objekti Graphics2D-objektiksi.
		Graphics2D g2D = (Graphics2D) g;
		
		g2D.setRenderingHint( RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON );
		
		// Piirret��n jokainen segmentti sek� kaksoispisteet.
		g2D.setColor( Color.BLACK );
		g2D.fillRect( getWidth() / 2 - 290, getHeight() / 2 - 50, 568, 144 );
		// Jos tuntinumeron kymmenet on nolla, sit� ei piirret�.
		if ( getHours() / 10 != 0 )
			drawSegments( g2D, getHours() / 10, 26);
		drawSegments( g2D, getHours() % 10, 106 );
		if ( colons )
			drawColons( g2D, 186 );
		drawSegments( g2D, getMinutes() / 10, 218 );
		drawSegments( g2D, getMinutes() % 10, 296 );
		if ( !colons )
			drawColons( g2D, 376 );
		drawSegments( g2D, getSeconds() / 10, 408 );
		drawSegments( g2D, getSeconds() % 10, 488 );
	}
	
	private void drawSegments( Graphics2D g, int number, int offset ) {
		g.setColor( Color.RED );
		
		// Haetaan taulukosta parametrina annettua numeroa vastaava boolean-esitys segmenteille.
		boolean[] segmentArray = segmentArrays[ number ];
		Polygon segment = null;
		
		// Luodaan segmenttipolygonit, siirret��n niit� offset-parametrin verran ja piirret��n segmentit.
		for ( int i = 0; i < 7; i++ ) {
			if ( segmentArray[ i ] ) {
				segment = new Polygon( xpointsArray[ i ], ypointsArray[ i ], totalPoints [ i ] );
				segment.translate( offset, getHeight() / 2 - 50 + 16 );
				g.fillPolygon( segment );
			}
		}
	}
	
	private void drawColons( Graphics2D g, int offset ) {
		g.fillOval( offset, getHeight() / 2 - 50 + 16 + 40, 16, 16 );
		g.fillOval( offset, getHeight() / 2 - 50 + 16 + 64, 16, 16 );
	}
}