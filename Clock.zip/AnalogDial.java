//import javax.swing.JPanel;
import java.util.Calendar;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.RadialGradientPaint;
import java.awt.Dimension;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;

public class AnalogDial extends BasicDial {
	
	// Ison sek� pienen kellotaulun v�rit.
	private RadialGradientPaint goldenEllipses;
	private RadialGradientPaint lemonChiffon;
	
	// Muuttujat tunti- ja minuuttiviisariolioille.
	private Polygon hourHand;
	private Polygon minuteHand;
	
	// Transformaatio-objekti tunti- ja minuuttiviisarien rotaatiota varten.
	private AffineTransform handRotation = null;
	
	public AnalogDial() {
		goldenEllipses = new RadialGradientPaint( 200.0f, 200.0f, 50.0f, 180.0f, 170.0f,
							new float[] { 0.0f, 0.85f, 1.0f },
							new Color[] { new Color( 255, 215, 0 ), new Color( 238, 221, 130 ),
							new Color( 218, 165, 32 ) }, RadialGradientPaint.CycleMethod.REFLECT );
		lemonChiffon = new RadialGradientPaint( 150.0f, 90.0f, 32.0f, new float[] { 0.0f, 0.35f, 1.0f },
							new Color[] { new Color( 255, 250, 205, 255 ), new Color( 255, 250, 205, 255 ),
								new Color( 255, 250, 205, 0 ) } );
		int[] xpointsHour = { 150, 142, 149, 159 };
		int[] ypointsHour = { 181, 172, 55, 172 };
		hourHand = new Polygon( xpointsHour, ypointsHour, 4 );
		int[] xpointsMinute = { 150, 141, 149, 158 };
		int[] ypointsMinute = { 180, 173, 35, 173 };
		minuteHand = new Polygon( xpointsMinute, ypointsMinute, 4 );
	}
	
	public void drawDial( Calendar time ) {
		setTime( time );
		repaint( 0 );
	}
	
	public Dimension getPreferredSize() {
		return new Dimension( 300, 320 );
	}
	
	protected void paintComponent( Graphics g ) {
		super.paintComponent( g );
		
		// Muunnetaan Graphics-objekti Graphics2D-objektiksi.
		Graphics2D g2D = (Graphics2D) g;
		
		g2D.setRenderingHint( RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON );
		
		// Piirret��n kellotaulut (koko kello ja millisekuntikello) sek� millisekuntiviisarin
		// keskipiste.
		g2D.setPaint( goldenEllipses );
		g2D.fillOval( 1, 21, 298, 298 );
		g2D.setColor( Color.BLACK );
		g2D.drawOval( 1, 21, 298, 298 );
		g2D.setPaint( lemonChiffon );
		g2D.fillOval( 118, 38 + 20, 64, 64 );
		g2D.setColor( Color.BLACK );
		g2D.fillOval( 148, 68 + 20, 4, 4 );
		
		// Piirret��n minuuttimerkit kellotaulun reunoille. Joka viidennen minuutin kohdalla
		// merkki piirret��n isommaksi.
		for ( int i = 0; i < 60; i++ ) {
			if ( i % 5 == 0 ) {
				g2D.fillOval( 8 + (int) (140 * (1 + Math.cos( i * Math.PI / 30 ))),
								8 + 20 + (int) (140 * (1 + Math.sin( i * Math.PI / 30 ))),
									4, 4 );
			}
			else {
				g2D.fillOval( 9 + (int) (140 * (1 + Math.cos( i * Math.PI / 30 ))),
								9 + 20 + (int) (140 * (1 + Math.sin( i * Math.PI / 30 ))),
									2, 2 );
			}
		}
		
		// Piirret��n merkit millisekuntiviisarille.
		for ( int i = 0; i < 10; i++ ) {
			g2D.fillRect( 128 + (int) (22 * (1 + Math.cos( Math.PI / 2 + i * Math.PI / 5 ))),
							47 + 20 + (int) (22 * (1 + Math.sin( Math.PI / 2 + i * Math.PI / 5 ))), 2, 2 );
		}
		
		// Lasketaan sijainti tuntiviisaria varten ja k��nnet��n viisari oikeaan aikaan.
		int hours = ( getHours() % 12 ) * 60 * 60 + getMinutes() * 60 + getSeconds();
		handRotation = AffineTransform.getRotateInstance( hours * 2 * Math.PI / ( 12 * 60 * 60 ), 150, 170 );
		g2D.fill( handRotation.createTransformedShape( hourHand ) );
		
		// Lasketaan sijainti minuuttiviisaria varten ja k��nnet��n viisari oikeaan aikaan.
		int minutes = getMinutes() * 60 + getSeconds();
		handRotation = AffineTransform.getRotateInstance( minutes * 2 * Math.PI / ( 60 * 60 ), 150, 170 );
		g2D.fill( handRotation.createTransformedShape( minuteHand ) );
		
		// Piirret��n kellotaulun keskipiste.
		g2D.setColor( Color.WHITE );
		g2D.fillOval( 143, 143 + 20, 14, 14 );
		g2D.setColor( Color.BLACK );
		g2D.fillOval( 146, 146 + 20, 8, 8 );
		
		// Piiret��n sekuntiviisari oikeaan kohtaan.
		int seconds = getSeconds();
		g2D.drawLine( (int) ( 150 - 140 * Math.cos( Math.PI / 2 + 2 * Math.PI * seconds / 60 ) ),
					(int) ( 20 + 150 - 140 * Math.sin( Math.PI / 2 + 2 * Math.PI * seconds / 60 ) ),	
					(int) ( 150 - 30 * Math.cos( 3 * Math.PI / 2 + 2 * Math.PI * seconds / 60 ) ),
					(int) ( 20 + 150 - 30 * Math.sin( 3 * Math.PI / 2 + 2 * Math.PI * seconds / 60 ) ) );
		
		// Piiret��n millisekuntiviisari oikeaan kohtaan.
		int milliSeconds = getMilliSeconds();
		g2D.drawLine( (int) ( 150 - 20 * Math.cos( Math.PI / 2 + 2 * Math.PI * milliSeconds / 1000 ) ),
					(int) ( 20 + 70 - 20 * Math.sin( Math.PI / 2 + 2 * Math.PI * milliSeconds / 1000 ) ),
					150, 70 + 20 );
	}
}