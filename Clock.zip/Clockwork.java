import java.util.GregorianCalendar;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.ArrayList;
import java.util.Iterator;

public class Clockwork implements Clock {
	
	private Calendar time;
	private boolean localTime;
	private TimeZone timeZone;
	private Ticker ticker;
	private ArrayList< Dial > dials;
	
	public Clockwork() {
		time = GregorianCalendar.getInstance();	
		localTime = true;
		timeZone = time.getTimeZone();
		initialize();
	}
	
	public Clockwork( GregorianCalendar gregCal ) {
		time = gregCal;
		localTime = false;
		timeZone = gregCal.getTimeZone();
		initialize();
	}
	
	private void initialize() {
		ticker = new TickerCore( this );
		dials = new ArrayList< Dial >();
	}
	
	public Calendar getTime() {
		return time;
	}
	
	public void setTime() {
		time = ( localTime ? GregorianCalendar.getInstance() : new GregorianCalendar( timeZone ) );
	}
		
	public void setTime( GregorianCalendar gregCal ) {
		time = gregCal;
	}
	
	public boolean isClockRunning() {
		return ticker.isTickerOn();
	}
	
	public void startClock() {
		if ( !isClockRunning() )
			ticker.startTicker();
	}
	
	public void stopClock() {
		if ( isClockRunning() )
			ticker.stopTicker();
	}
	
	public void addDial( Dial dial ) {
		if ( !dials.contains( dial ) )
			dials.add( dial );
	}
	
	public boolean removeDial( Dial dial ) {
		return dials.remove( dial );
	}
	
	public void updateDials() {
		Iterator< Dial > iterator = dials.iterator();
		Calendar currentTime = getTime();
		while ( iterator.hasNext() ) {
			iterator.next().drawDial( currentTime );
		}
	}
}