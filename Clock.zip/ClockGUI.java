import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ClockGUI extends JPanel {
	
	private Clock clock;
	private Dial[] dials;
	private int[] number = { 0, 1, 2 };
	private JButton startButton;
	private JButton stopButton;
	private JButton[] startButtons;
	private JButton[] stopButtons;
	private boolean[] startTruthValues;
	private boolean[] stopTruthValues;
	
	public ClockGUI() {
		this( false );
	}
	
	public ClockGUI( boolean withSound ) {
		
		// Luodaan paneelit kellotauluja ja nimikentti� varten.
		JPanel analogPanel = new JPanel();
		JPanel digitalPanel = new JPanel();
		JPanel lightBulbPanel = new JPanel();
		JPanel clockPanels[] = { analogPanel, digitalPanel, lightBulbPanel };
		
		// Luodaan nimikentt� kullekin kellotaululle.
		JLabel analogLabel = new JLabel( "Analog Display" );
		JLabel digitalLabel = new JLabel( "Digital Display" );
		JLabel lightBulbLabel = new JLabel( "Light Bulb Display" );
		JLabel labels[] = {analogLabel, digitalLabel, lightBulbLabel };
		
		// Luodaan kellotaulut.
		Dial analog = new AnalogDial();
		Dial digital = new DigitalDial();
		Dial lightBulbs = new LightBulbDial();
		Dial[] dialArray = { analog, digital, lightBulbs };
		dials = dialArray;
		
		// Luodaan kontrollinappulat paneeleineen jokaista kelloa varten.
		JButton analogStart = new JButton( "Start" );
		JButton analogStop = new JButton( "Stop" );
		JButton digitalStart = new JButton( "Start" );
		JButton digitalStop = new JButton( "Stop" );
		JButton bulbStart = new JButton( "Start" );
		JButton bulbStop = new JButton( "Stop" );
		JButton[] starts = { analogStart, digitalStart, bulbStart };
		startButtons = starts;
		JButton[] stops = { analogStop, digitalStop, bulbStop };
		stopButtons = stops;
		JPanel analogButtons = new JPanel();
		JPanel digitalButtons = new JPanel();
		JPanel lightbulbButtons = new JPanel();
		JPanel[] buttonPanels = { analogButtons, digitalButtons, lightbulbButtons };
		
		startTruthValues = new boolean[ 3 ];
		stopTruthValues = new boolean[ 3 ];
		
		// Luodaan kello, joka p�ivitt�� kellotauluja.
		clock = new Clockwork();
					
		// J�rjestell��n kellotaulut ja nimikent�t omiin paneeleihin.
		for ( int i = 0; i < 3; i++ ) {
			clockPanels[ i ].setLayout( new BorderLayout() );
			labels[ i ].setHorizontalAlignment( SwingConstants.CENTER );
			clockPanels[ i ].add( labels[ i ], BorderLayout.NORTH );
			clockPanels[ i ].add( (JPanel) dials[ i ], BorderLayout.CENTER );
			startTruthValues[ i ] = false;
			stopTruthValues[ i ] = true;
			final int j = i;
			startButtons[ number[ j ] ].addActionListener( new ActionListener() {
				public void actionPerformed( ActionEvent e ) {
					if ( clock.isClockRunning() ) {
						clock.addDial( dials[ number[ j ] ] );
						startButtons[ number[ j ] ].setEnabled( false );
						startTruthValues[ number[ j ] ] = false;
						stopButtons[ number[ j ] ].setEnabled( true );
						stopTruthValues[ number[ j ] ] = true;
					}
				}
			});
			stopButtons[ number[ j ] ].addActionListener( new ActionListener() {
				public void actionPerformed( ActionEvent e ) {
					if ( clock.isClockRunning() ) {
						clock.removeDial( dials[ number[ j ] ] );
						stopButtons[ number[ j ] ].setEnabled( false );
						stopTruthValues[ number[ j ] ] = false;
						startButtons[ number[ j ] ].setEnabled( true );
						startTruthValues[ number[ j ] ] = true;
					}
				}
			});
			startButtons[ i ].setEnabled( false );
			buttonPanels[ i ].setLayout( new FlowLayout() );
			buttonPanels[ i ].add( startButtons[ i ] );
			buttonPanels[ i ].add( stopButtons [ i ] );
			clockPanels[ i ].add( buttonPanels[ i ], BorderLayout.SOUTH );
			clock.addDial( dials[ i ] );
		}
		
		// Luodaan nappulat kaikkien kellojen pys�ytt�mist� ja k�ynnist�mist� varten.
		stopButton = new JButton( "Stop ticker" );
		startButton = new JButton( "Start ticker" );
		startButton.setEnabled( false );
		
		// Luodaan tapahtumankuuntelijat nappuloille.
		startButton.addActionListener( new ActionListener() {
			public void actionPerformed( ActionEvent e ) {
				clock.startClock();
				startButton.setEnabled( false );
				stopButton.setEnabled( true );
				for ( int i = 0; i < 3; i++ ) {
					if ( startTruthValues[ i ] )
						startButtons[ i ].setEnabled( true );
					if ( stopTruthValues[ i ] )
						stopButtons[ i ].setEnabled( true );
				}
			}
		});
		stopButton.addActionListener( new ActionListener() {
			public void actionPerformed( ActionEvent e ) {
				clock.stopClock();
				stopButton.setEnabled( false );
				startButton.setEnabled( true );
				for ( int i = 0; i < 3; i++ ) {
					if ( startButtons[ i ].isEnabled() )
						startButtons[ i ].setEnabled( false );
					if ( stopButtons[ i ].isEnabled() )
						stopButtons[ i ].setEnabled( false );
				}
			}
		});
		
		// Luodaan paneelit ja nappulat lopullista n�kym�� varten ja rakennetaan k�ytt�liittym� valmiiksi.
		JPanel upperPanel = new JPanel();
		JPanel lowerPanel = new JPanel();
		JPanel buttonPanel = new JPanel();
		upperPanel.setLayout( new FlowLayout() );
		upperPanel.add( analogPanel );
		upperPanel.add( lightBulbPanel );
		lowerPanel.add( digitalPanel, BorderLayout.NORTH );
		buttonPanel.setLayout( new FlowLayout() );
		buttonPanel.add( startButton );
		buttonPanel.add( stopButton );
		lowerPanel.add( buttonPanel, BorderLayout.CENTER );
		setLayout( new GridLayout( 2, 1 ) );
		add( upperPanel );
		add( lowerPanel );
		
		// K�ynnistet��n kello.
		clock.startClock();
	}
}