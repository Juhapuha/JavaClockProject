import javax.swing.SwingUtilities;
import javax.swing.JFrame;
//import javax.swing.JApplet;
import java.awt.Toolkit;
import java.awt.Dimension;
//import java.lang.reflect.InvocationTargetException;

public class ClockProject /*extends JApplet*/ {
	/*
	public void init() {
		try {
	    	javax.swing.SwingUtilities.invokeAndWait( new Runnable() {
				public void run() {
					getContentPane().add( new ClockGUI() );
				}
	    	});
		}
		catch ( InvocationTargetException invEx ) {
			invEx.printStackTrace();
		}
		catch ( InterruptedException interruptedEx ) {
			System.err.println( "ClockGUI creation didn't complete succesfully" );
		}
	}
	*/
	public static void main (String[] args) {
		
		SwingUtilities.invokeLater( new Runnable() {
			public void run() {
				JFrame frame = new JFrame( "Clocks" );
				frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
				Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
				frame.setBounds( (int) screenSize.getWidth() / 2 - 350, (int) screenSize.getHeight() / 8, 700, 780 );
				frame.setResizable( false );
				frame.add( new ClockGUI() );
				frame.setVisible( true );
			}
		});
	}
}