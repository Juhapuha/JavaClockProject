import javax.swing.Timer;
//import java.util.Timer;
//import java.util.TimerTask;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TickerCore implements Ticker {
	
	private Clockwork clock;
	private Timer timer;
		
	public TickerCore( Clockwork clock ) {
		this.clock = clock;
		timer = new Timer( 50, createTick() );
	}
	
/*	public TickerCore( Clockwork clock ) {
		this.clock = clock;
		this.timer = new Timer();
	}
*/	
	private ActionListener createTick() {
		return new ActionListener() {
			public void actionPerformed( ActionEvent e ) {
				clock.setTime();
				clock.updateDials();
			}
		};
	}
/*	private TimerTask createTick() {
		return new TimerTask() {
			public void run() {
				clock.setTime();
				clock.updateDials();
			}
		};
	}
*/	
	public void startTicker() {
		while ( System.currentTimeMillis() % 1000 < 950 ) {
		}
		timer.start();
	}
	
/*	public void startTicker() {
		this.timer.scheduleAtFixedRate( createTick(),
					(int) ( 1000 - System.currentTimeMillis() % 1000 ), 50 );
	}
*/	
	public void stopTicker() {
		timer.stop();
	}

/*	public void stopTicker() {
		this.timer.cancel();
	}
*/
	public boolean isTickerOn() {
		return timer.isRunning();
	}
}