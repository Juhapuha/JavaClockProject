import java.util.Calendar;
import java.util.GregorianCalendar;

public interface Clock {
	
	public void setTime();
	
	public void setTime( GregorianCalendar greCal );
	
	public Calendar getTime();
	
	public boolean isClockRunning();
	
	public void startClock();
	
	public void stopClock();
	
	public void addDial( Dial dial );
	
	public boolean removeDial( Dial dial );
}