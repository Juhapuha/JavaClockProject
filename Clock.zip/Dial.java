import java.util.Calendar;

public interface Dial {
	
	public void drawDial( Calendar time );
}