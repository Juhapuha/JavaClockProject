import javax.swing.JPanel;
import java.util.Calendar;
import java.util.GregorianCalendar;

public abstract class BasicDial extends JPanel implements Dial {
	
	private Calendar time = new GregorianCalendar( 0, 0, 0, 0, 0, 0 );
	
	protected int getHours() {
		return time.get( Calendar.HOUR_OF_DAY );
	}
	
	protected int getMinutes() {
		return time.get( Calendar.MINUTE );
	}
	
	protected int getSeconds() {
		return time.get( Calendar.SECOND );
	}
	
	protected int getMilliSeconds() {
		return time.get( Calendar.MILLISECOND );
	}
	
	protected void setTime( Calendar time ) {
		this.time = time;
	}
	
	public abstract void drawDial( Calendar time );
}