

public interface Ticker {
	
	public void startTicker();
	
	public void stopTicker();
	
	public boolean isTickerOn();
}